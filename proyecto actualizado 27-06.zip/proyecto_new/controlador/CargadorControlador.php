<?php
header('Content-Type: application/json');

// Configuración de la base de datos
$host = "localhost";
$user = "root";
$pass = "root";
$db = "gestion_db";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    echo json_encode(['exito' => false, 'mensaje' => 'Error de conexión a la base de datos']);
    exit;
}

// Detectar la acción
$accion = '';
if (isset($_GET['accion'])) {
    $accion = $_GET['accion'];
} elseif (isset($_POST['accion'])) {
    $accion = $_POST['accion'];
} else {
    // Para agregar, puede venir por JSON
    $input = json_decode(file_get_contents('php://input'), true);
    if (isset($input['accion'])) {
        $accion = $input['accion'];
    }
}

// LISTAR cargadores
if ($accion === 'listar') {
    $sql = "SELECT * FROM cargadores";
    $result = $conn->query($sql);
    $cargadores = [];
    while($row = $result->fetch_assoc()) {
        $cargadores[] = $row;
    }
    echo json_encode($cargadores);
    $conn->close();
    exit;
}

// AGREGAR cargador
if ($accion === 'agregar') {
    $data = json_decode(file_get_contents('php://input'), true);
    if (!$data) $data = $_POST;
    $nombre = $data['nombre'] ?? '';
    $latitud = $data['latitud'] ?? '';
    $longitud = $data['longitud'] ?? '';
    if ($nombre === '' || $latitud === '' || $longitud === '') {
        echo json_encode(['exito' => false, 'mensaje' => 'Datos incompletos']);
        $conn->close();
        exit;
    }
    $stmt = $conn->prepare("INSERT INTO cargadores (nombre, latitud, longitud) VALUES (?, ?, ?)");
$stmt->bind_param("sdd", $nombre, $latitud, $longitud);
    if ($stmt->execute()) {
        echo json_encode(['exito' => true]);
    } else {
        echo json_encode(['exito' => false, 'mensaje' => 'No se pudo agregar']);
    }
    $stmt->close();
    $conn->close();
    exit;
}

// ELIMINAR cargador
if ($accion === 'eliminar') {
    $id = $_POST['id'] ?? null;
    if ($id === null) {
        // Intentar obtener de JSON
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $data['id'] ?? null;
    }
    if ($id === null) {
        echo json_encode(['exito' => false, 'mensaje' => 'ID no recibido']);
        $conn->close();
        exit;
    }
    $id = intval($id);
    $stmt = $conn->prepare("DELETE FROM cargadores WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        echo json_encode(['exito' => true, 'mensaje' => 'Cargador eliminado']);
    } else {
        echo json_encode(['exito' => false, 'mensaje' => 'No se pudo eliminar el cargador']);
    }
    $stmt->close();
    $conn->close();
    exit;
}

// Si no se reconoce la acción
echo json_encode(['exito' => false, 'mensaje' => 'Acción no válida']);
$conn->close();
?>