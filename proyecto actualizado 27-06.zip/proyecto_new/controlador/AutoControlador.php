<?php
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "gestion_db"; // Cambia esto por tu base de datos

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(['exito' => false, 'error' => 'Error de conexión']);
    exit;
}

// Detectar si la petición es JSON o POST tradicional
if ($_SERVER['CONTENT_TYPE'] === 'application/json') {
    $data = json_decode(file_get_contents('php://input'), true);
} else {
    $data = $_POST;
}

$accion = isset($data['accion']) ? $data['accion'] : '';

switch ($accion) {
    case 'agregar':
        $modelo = $data['modelo'];
        $marca = $data['marca'];
        $conector = $data['conector'];
        $autonomia = $data['autonomia'];
        $anio = $data['anio'];

        $stmt = $conn->prepare("INSERT INTO autos (modelo, marca, conector, autonomia, anio) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssii", $modelo, $marca, $conector, $autonomia, $anio);

        if ($stmt->execute()) {
            echo json_encode(['exito' => true]);
        } else {
            echo json_encode(['exito' => false, 'error' => $stmt->error]);
        }
        $stmt->close();
        break;

    case 'editar':
        $id = $data['id'];
        $modelo = $data['modelo'];
        $marca = $data['marca'];
        $conector = $data['conector'];
        $autonomia = $data['autonomia'];
        $anio = $data['anio'];

        $stmt = $conn->prepare("UPDATE autos SET modelo=?, marca=?, conector=?, autonomia=?, anio=? WHERE id=?");
        $stmt->bind_param("sssiii", $modelo, $marca, $conector, $autonomia, $anio, $id);

        if ($stmt->execute()) {
            echo json_encode(['exito' => true]);
        } else {
            echo json_encode(['exito' => false, 'error' => $stmt->error]);
        }
        $stmt->close();
        break;

    case 'eliminar':
        $id = $data['id'];
        $stmt = $conn->prepare("DELETE FROM autos WHERE id=?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo json_encode(['exito' => true]);
        } else {
            echo json_encode(['exito' => false, 'error' => $stmt->error]);
        }
        $stmt->close();
        break;

    case 'listar':
        $sql = "SELECT * FROM autos ORDER BY id DESC";
        $result = $conn->query($sql);
        $autos = [];
        while($row = $result->fetch_assoc()) {
            $autos[] = $row;
        }
        echo json_encode($autos);
        break;

    default:
        echo json_encode(['exito' => false, 'error' => 'Acción no válida']);
        break;
}

$conn->close();
?>