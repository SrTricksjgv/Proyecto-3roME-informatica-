<?php
require_once __DIR__ . '/../db.php';

class UsuarioLogin {
    private $conexion;

    public function __construct() {
        $this->conexion = conectar();
    }

    public function verificarCredenciales($usuario, $password) {
        $sql = "SELECT * FROM usuarios_login WHERE usuario = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([$usuario]);
        $usuarioData = $stmt->fetch(PDO::FETCH_ASSOC);
        

        if ($usuarioData && password_verify($password, $usuarioData['password'])) {  
            return $usuarioData;
        }else{
            return false;
        }
        
    }

    public function obtenerTipoUsuario($usuario) {
        $sql = "SELECT tipo_usuario FROM usuarios_login WHERE usuario = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([$usuario]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? $row['tipo_usuario'] : null;
    }
}
?>